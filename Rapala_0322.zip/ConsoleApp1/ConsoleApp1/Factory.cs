﻿
using System;

using System.Net;

using Ionic.Zip;

using System.Collections.Generic;



namespace ConsoleApp1

{

    class Program

    {

        static void Main(string[] args)

        {

            Download0 d0 = new Download0();

            d0.DownloadFile(1, 1);



            Download d = new DownloadFromBossa(new ErrorMessageToFile());

            d.DownloadFile();







            ISignals s1 = Factory.CreateSignal("a");

            Operations op = new Operations(s1);



            s1.xx(new List<(string, double)>() { ("a", 32), ("b", 34), ("c", 38) });









        }

    }





    interface ISignals

    {

        List<(string dt, bool sg)> xx(List<(string dt, double pr)> D);

        string[] dates { get; set; }

        bool[] signals { get; set; }

    }



    class MavSignals : ISignals

    {

        public string[] dates { get; set; }

        public bool[] signals { get; set; }

        public List<(string dt, bool sg)> xx(List<(string dt, double pr)> D)

        {

            Random R = new Random();

            List<(string dt, bool sg)> Signals = new List<(string, bool)>();

            for (int i = 0; i < 12; i++)

            {

                Signals.Add((D[R.Next(0, D.Count)].dt, false));

                Signals.Add((D[R.Next(0, D.Count)].dt, true));

            }



            return Signals;

        }



    }



    class MacdSignals : ISignals

    {

        public string[] dates { get; set; }

        public bool[] signals { get; set; }

        public List<(string dt, bool sg)> xx(List<(string dt, double pr)> D)

        {

            Random R = new Random();

            List<(string dt, bool sg)> Signals = new List<(string, bool)>();

            for (int i = 0; i < 12; i++)

            {

                Signals.Add((D[R.Next(0, D.Count)].dt, false));

                Signals.Add((D[R.Next(0, D.Count)].dt, true));

            }



            return Signals;

        }



    }





    class RsiSignals : ISignals

    {

        public string[] dates { get; set; }

        public bool[] signals { get; set; }

        public List<(string dt, bool sg)> xx(List<(string dt, double pr)> D)

        {

            Random R = new Random();

            List<(string dt, bool sg)> Signals = new List<(string, bool)>();

            for (int i = 0; i < 12; i++)

            {

                Signals.Add((D[R.Next(0, D.Count)].dt, false));

                Signals.Add((D[R.Next(0, D.Count)].dt, true));

            }



            return Signals;

        }



    }





    class Factory

    {

        public static ISignals CreateSignal(string type)

        {

            ISignals sg;

            switch (type)

            {

                case "m": return new MavSignals(); break;

                case "a": return new MacdSignals(); break;

                default: return new RsiSignals(); break;

            }



        }



    }









    // ********************************************************************************************************************



    class Operations

    {

        ISignals _sg;

        public Operations(ISignals sg)

        {

            _sg = sg;

        }



     /*   public void DoAll()

        {

            _sg.xx(...);

        }


    */


    }













    // ********************************************************************************************************************

    class Download0 //This class violates the Single Responsibility Principle and The Open-Closed Principle

    {

        public void DownloadFile(int source, int err)

        {



            WebClient client = new WebClient();

            try

            {

                if (source == 1)

                {

                    client.DownloadFile("https://www.bankier.pl/inwestowanie/profile/quote.html?symbol=PKNORLEN", @"C:\ZTP\bossa\bankier.html");

                }

                else if (source == 2)

                {

                    client.DownloadFile("http://bossa.pl/pub/metastock/mstock/mstall.zip", @"C:\ZTP\bossa\mstall.zip");

                    using (ZipFile zip = ZipFile.Read(@"C:\ZTP\bossa\mstall.zip"))

                    {

                        zip.ExtractAll(@"C:\ZTP\bossa");

                    }

                }

            }

            catch (Exception exc)

            {

                if (err == 1)

                {

                    System.IO.File.AppendAllText(@"C:\ZTP\bossa\log.txt", exc.Message);

                }

                else if (err == 2)

                {

                    Console.WriteLine(exc.Message);

                }

            }

        }

    }









    // ********************************************************************************************************************

    abstract class Download  //Now better. To be continue next week

    {

        protected ErrorMessage erm;

        protected WebClient client = new WebClient();



        public Download(ErrorMessage erm)

        {

            this.erm = erm;

        }





        public void DownloadFile()

        {

            try

            {

                DoDownload();

            }

            catch (Exception exc)

            {

                erm.GetError(exc.Message);

            }



        }



        protected virtual void DoDownload()

        {



        }

    }



    class DownloadFromBossa : Download

    {



        public DownloadFromBossa(ErrorMessage erm) : base(erm)

        {

        }



        protected override void DoDownload()

        {

            client.DownloadFile("http://bossa.pl/pub/metastock/mstock/mstall.zip", @"C:\ZTP\bossa\mstall.zip");

            using (ZipFile zip = ZipFile.Read(@"C:\ZTP\bossa\mstall.zip"))

            {

                zip.ExtractAll(@"C:\ZTP\bossa");

            }

        }

    }



    class DownloadFromBankier : Download

    {



        public DownloadFromBankier(ErrorMessage erm) : base(erm)

        {

        }

        protected override void DoDownload()

        {

            client.DownloadFile("https://www.bankier.pl/inwestowanie/profile/quote.html?symbol=PKNORLEN", @"C:\ZTP\bossa\bankier.html");

        }

    }



    abstract class ErrorMessage

    {



        public virtual void GetError(string message)

        {



        }

    }



    class ErrorMessageToFile : ErrorMessage

    {

        public override void GetError(string message)

        {

            System.IO.File.AppendAllText(@"C:\ZTP\bossa\log.txt", message);

        }

    }



    class ErrorMessageToUser : ErrorMessage

    {

        public override void GetError(string message)

        {

            Console.WriteLine(message);

        }

    }



}




