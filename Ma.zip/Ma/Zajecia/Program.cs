﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ma;

namespace Zajecia
{
    class Program
    {
        static void Main(string[] args)
        {
            Indicators ind = new Indicators();
            Dictionary<string, string> w = ind.Wskazniki(15, @"C:\Users\student\Desktop\Nowy folder (2)\ABPL.mst");

            foreach (var item in w)
            {
                Console.WriteLine($"Data {item.Key} = {item.Value}");
            }

            Console.Read();

        }
    }
}
