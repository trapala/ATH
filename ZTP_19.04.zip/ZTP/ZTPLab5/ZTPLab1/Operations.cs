﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;

namespace ZTPLab1
{
	class Operations
	{
		public Dictionary<string, double> ReadFile()
		{
			Dictionary<string, double> dictionary = new Dictionary<string, double>();

			string fileContent = File.ReadAllText(@"C:\ZTP\bossa\ZYWIEC.mst");
			string[] contentLines = fileContent.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

			for (int i = 1; i < contentLines.Length; i++)
			{
				string[] contentParts = contentLines[i].Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                double readValue = double.Parse(contentParts[5], CultureInfo.InvariantCulture);
                dictionary.Add(contentParts[1], readValue);
				Console.WriteLine("ODCZYT = {0} ; {1}", contentParts[1], readValue);
			}

			return dictionary;
		}

		public void WriteFile()
		{

		}

	}


	public class Method
	{
		/*public Dictionary<string, double> ReadFile(Dictionary<string, double> D)
		{

		}*/
	}
}
