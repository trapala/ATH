﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZTPLab1
{
	class Program
	{
		static void Main(string[] args)
		{
			//DownloadBankier download = new DownloadBankier(new CatchExceptionScreen());
			//DownloadBossa download = new DownloadBossa(new CatchExceptionFile());
			//download.DownloadFile();

			Operations operations = new Operations();
            //operations.ReadFile();

            Price price = new Price(100);
            Console.WriteLine("Default Price value = {0}", price.GetCost());

            Console.WriteLine("EUR/PLN Price value = {0}", new PriceEURPLN(price).GetCost());
            Console.WriteLine("USD/PLN Price value = {0}", new PriceUSDPLN(price).GetCost());


            Console.ReadKey();
		}
	}
}
