﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZTPLab1
{
    public interface IPrice
    {
        double GetCost();
    }

    public class Price : IPrice
    {
        double _priceValue;

        public Price(double priceValue)
        {
            _priceValue = priceValue;
        }

        public double GetCost()
        {
            return _priceValue;
        }
    }

    public abstract class PriceDecorator : IPrice
    {
        private IPrice _price;

        public PriceDecorator(IPrice price)
        {
            this._price = price;
        }

        public virtual double GetCost()
        {
            return this._price.GetCost();
        }
    }

    public class PriceEURPLN : PriceDecorator
    {
        public PriceEURPLN(IPrice price) : base(price)
        {
        }

        public override double GetCost()
        {
            return base.GetCost() * 4.197;
        }
    }

    public class PriceProvision : PriceDecorator
    {
        public PriceProvision(IPrice price) : base(price)
        {
        }

        public override double GetCost()
        {
            return base.GetCost() * 0.9;
        }
    }

    public class PriceUSDPLN : PriceDecorator
    {
        public PriceUSDPLN(IPrice price) : base(price)
        {
        }

        public override double GetCost()
        {
            return base.GetCost() * 3.43;
        }
    }
}
