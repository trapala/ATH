﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectKK
{
	public abstract class CatchException
	{
		public abstract void Log(Exception exc);
	}


	public class CatchExceptionFile : CatchException
	{
		public override void Log(Exception exc)
		{
			System.IO.File.AppendAllText(@"C:\ZTP\bossa\log.txt", exc.Message);
		}
	}


	public class CatchExceptionScreen : CatchException
	{
		public override void Log(Exception exc)
		{
			Console.WriteLine(exc.Message);
		}
	}
}
