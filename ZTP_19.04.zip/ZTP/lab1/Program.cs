﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ProjectKK
{
    class Program
    {
        static void Main(string[] args)
        {
			
			try
			{
				DownloadBossa dBossa = new DownloadBossa();
				dBossa.DownloadFile();

				//DownloadBankier dBankier = new DownloadBankier();
				//dBankier.DownloadFile();
			}
			catch(Exception exc)
			{
				CatchExceptionScreen ceScreen = new CatchExceptionScreen();
				ceScreen.Log(exc);
			}
        }
    }
}
