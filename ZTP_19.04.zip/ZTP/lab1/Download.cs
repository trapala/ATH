﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using Ionic.Zip;

namespace ProjectKK
{
	public abstract class Download
	{
		protected WebClient client;

		public Download()
		{
			client = new WebClient();
		}

		public abstract void DownloadFile();
	}


	public class DownloadBossa : Download
	{
		public override void DownloadFile()
		{
			client.DownloadFile("http://bossa.pl/pub/metastock/mstock/mstall.zip", @"C:\ZTP\bossa\mstall.html");
		}
	}


	public class DownloadBankier : Download
	{
		public override void DownloadFile()
		{
			client.DownloadFile("https://bankier.pl/inwestowanie/profile/quote.html?symbol=PKNORLEN", @"C:\ZTP\bossa\mstall.html");
			using (ZipFile zip = ZipFile.Read(@"C:\ZTP\bossa\mstall.html"))
			{
				zip.ExtractAll(@"C:\ZTP\bossa");
			}
		}
	}
}
