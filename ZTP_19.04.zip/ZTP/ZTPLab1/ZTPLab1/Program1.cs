﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZTPLab1
{
	class Program
	{
		static void Main(string[] args)
		{
			//DownloadBankier download = new DownloadBankier(new CatchExceptionScreen());
			DownloadBossa download = new DownloadBossa(new CatchExceptionFile());
			//download.DownloadFile();

			Operations operations = new Operations();
			operations.ReadFile();

			Console.ReadKey();
		}
	}
}
