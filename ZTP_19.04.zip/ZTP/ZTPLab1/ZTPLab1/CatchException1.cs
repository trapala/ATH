﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZTPLab1
{
	public abstract class CatchException
	{
		public abstract void Log(string mssg);
	}


	public class CatchExceptionFile : CatchException
	{
		public override void Log(string mssg)
		{
			System.IO.File.AppendAllText(@"C:\ZTP\bossa\log.txt", mssg);
		}
	}


	public class CatchExceptionScreen : CatchException
	{
		public override void Log(string mssg)
		{
			Console.WriteLine(mssg);
		}
	}
}
