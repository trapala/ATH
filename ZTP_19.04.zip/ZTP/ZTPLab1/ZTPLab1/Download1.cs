﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using Ionic.Zip;

namespace ZTPLab1
{
	public abstract class Download
	{
		protected WebClient client = new WebClient();
		protected CatchException exc;

		public Download(CatchException exception)
		{
			exc = exception;
		}

		public void DownloadFile()
		{
			try
			{
				DownloadStart();
			}
			catch (Exception e)
			{
				exc.Log(e.Message);
			}
		}

		public abstract void DownloadStart();
	}


	public class DownloadBossa : Download
	{
		public DownloadBossa(CatchException exception) : base(exception)
		{
		}

		public override void DownloadStart()
		{
			client.DownloadFile("http://bossa.pl/pub/metastock/mstock/mstall.zip", @"C:\ZTP\bossa\mstall.zip");
			using (ZipFile zip = ZipFile.Read(@"C:\ZTP\bossa\mstall.zip"))
			{
				zip.ExtractAll(@"C:\ZTP\bossa");
			}
		}
	}


	public class DownloadBankier : Download
	{
		public DownloadBankier(CatchException exception) : base(exception)
		{
		}

		public override void DownloadStart()
		{
			client.DownloadFile("https://www.bankier.pl/inwestowanie/profile/quote.html?symbol=PKNORLEN", @"C:\ZTP\bossa\mstall.html");
		}
	}
}
